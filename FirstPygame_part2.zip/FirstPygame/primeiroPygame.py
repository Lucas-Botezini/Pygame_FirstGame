import pygame
from sys import exit # Import the Sys so you can close the game

def display_score():

    current_time = int(pygame.time.get_ticks() / 1000) - start_time
    score_surf = test_font.render(f"Tempo: {current_time}s", False, "Black")  # Score of the game
    score_rect = score_surf.get_rect(midright=(750,30))
    screen.blit(score_surf,score_rect)
    return current_time

pygame.init() # Start the pygame

# Opening the game screen and Icons
screen = pygame.display.set_mode((800, 400))  # First number is width and Second is height. This is the screen of the game
pygame.display.set_caption('Jumper')    # Set the title of the game
gameIcon = pygame.image.load('graphics/icon.png')  # Set the icon in a var
pygame.display.set_icon(gameIcon)   # Set the icon in the game
score = 0

# Font and Fps
clock = pygame.time.Clock()     # Add a timer - Help to set the Frames Per Second (fps) - You have to put it in the "while True" loop to work
test_font = pygame.font.Font('font/Pixeltype.ttf', 30)   # Add a font (fonte, tamanho da fonte)

# All images the graphics need to contain a ".convert()" so pygame can work better
game_active = False

start_time = 0

# Graphics Images           - The order displayed here, is the order they program will read the images
sky_surface = pygame.image.load('Images/Sky.png').convert()     # Add a Image
ground_surface = pygame.image.load('graphics/ground.png').convert() # Convert() is used so pygame can run the game better

text1 = "The Jumper"
text_surface = test_font.render( text1, False, "Red") # Write the text, say if you want him Anti-Aliase, set the color


# score_surf = test_font.render('Score: ', False, "Black")  # Score of the game
# score_rect = score_surf.get_rect(midright=(750,30))



# Enemy
snail_surface = pygame.image.load('graphics/snail/snail1.png').convert_alpha()  # Enemy image - Use "convert_alpha()" in the Enemy
# snail_x_position = 600      # Snail position in a var.
snail_rect = snail_surface.get_rect(midbottom = (600,300))


# Player
player_surface = pygame.image.load('graphics/Player/player_stand.png')
player_rect = player_surface.get_rect(bottomleft=(60, 300))
player_gravity = 0

# Intro Screen
player_surface_intro = pygame.image.load('graphics/Player/player_stand.png').convert_alpha()
player_surface_intro = pygame.transform.scale2x(player_surface_intro)
player_intro_rect = player_surface_intro.get_rect(center=(400, 200))

# test_surface = pygame.Surface((100,200)) # First number is width and Second is height
# test_surface.fill('Red')

text_rect = text_surface.get_rect(center = (400,30))


while True:     # Loop to run the game, and to update it.
    for event in pygame.event.get():
        if event.type == pygame.QUIT:   # Event to close the game
            pygame.quit()
            exit()

        if game_active:

        # Events
            if event.type == pygame.MOUSEBUTTONDOWN:    # This gives the mouse position, but only if you move it "MOUSEMOTION"
                if player_rect.collidepoint(event.pos) and player_rect.bottom >= 300:
                    player_gravity = -10


            # if event.type == pygame.MOUSEBUTTONUP:
            #     print("Release the button to appear this message")

            # if event.type == pygame.MOUSEBUTTONDOWN:
            #     print("Click a button to appear this message")

        # Event Key Input

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP and player_rect.bottom >= 300:
                    player_gravity = -12
        else:


            if event.type == pygame.KEYDOWN and event.key == pygame.K_UP:
                game_active = True
                snail_rect.left = 800
                start_time = int(pygame.time.get_ticks() / 1000)

# BE CAREFUL in the order that is written the code, because this is how WILL APPEAR
    if game_active:
        screen.blit(sky_surface,(0,0))      # Add things to the surface
        screen.blit(ground_surface,(0,300))
        # pygame.draw.rect(screen,(16, 235, 213), score_rect,0,10) # Draw Rect, search to view the needs to draw it
        # screen.blit(text_surface,text_rect)
        # screen.blit(score_surf,score_rect)
        score = display_score()

        # pygame.draw.line(screen,"Red", (0,0),pygame.mouse.get_pos(), 10)      It can pick a line of any position I want
        # snail_x_position += -4      # Change the x position of the Snail after each loop - Will make the Enemy "Walk"

        # if snail_x_position < -100:  # This will make the Enemy come back to the value set down there (800), This will happen after the enemy reach -100
        #     snail_x_position = 800

        # screen.blit(snail_surface,(snail_x_position, 250))  # (X,Y) Position of Enemy in game

        snail_rect.x += -7      # Moves the snail to the right

        if snail_rect.right <= 0:  # Here we pick the right side of the snail, and compare with "0" (the number I want)
            snail_rect.left = 800  # Here the left part of the snail returns to 800

        screen.blit(snail_surface, snail_rect)


    # KeyBoard Input
    #     keys = pygame.key.get_pressed()         # Putting the method in a var
        # if keys[pygame.K_SPACE]:       # Checking if the K_"Button" is pressed, and printing something if it is
        #     player_gravity += -10

    # Gravity
        player_gravity += 0.5
        player_rect.y += player_gravity

        if player_rect.bottom >= 300:
            player_rect.bottom = 300

        screen.blit(player_surface, player_rect)

        # screen.blit(enemies, (700, 100))

        # player_rect.colliderect(snail_rect)     #  This see the collision between two objects

        # if player_rect.colliderect(snail_rect):    # Python makes the condition False when there is no collision, and when has collision is True
        #     print("collision")


    # Using the mouse to get the collision point
        # mouse_pos = pygame.mouse.get_pos()      # Here we are getting the mouse position

        # Player.rect can be traded for snail.rect and will still work
        # if player_rect.collidepoint(mouse_pos): # Here we use the mouse position when is in contact with the object we want

            # print("Collision")
            # print(pygame.mouse.get_pressed())   # Return condition when the mouse is pressed, booleans.

        if snail_rect.colliderect(player_rect):
            game_active = False

    else:
        screen.fill((94, 129 , 162))

        name = "The Jumper Game"
        name_surface = test_font.render(name, False, "Black")
        name_rect = name_surface.get_rect(topleft = (40, 30))
        screen.blit(name_surface,name_rect)

        text1 = "Para comecar o jogo aperte UP"
        text_surface = test_font.render(text1, False, "Black")
        text_rect = text_surface.get_rect(topright=(760, 30))

        score_message = test_font.render(f"Seu tempo foi {score}s", False, "Black")
        score_rect = score_message.get_rect(topright = (760,30))

        screen.blit(player_surface_intro, player_intro_rect)

        if score == 0:
            screen.blit(text_surface, text_rect)
        else:
            screen.blit(score_message,score_rect)





    pygame.display.update()
    clock.tick(60)      # Say how many times the image is updated in a second, try putting it to 1 or 600 to test. Use the clock var called back then





