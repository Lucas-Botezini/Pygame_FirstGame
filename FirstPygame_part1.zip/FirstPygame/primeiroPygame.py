import pygame
from sys import exit # Import the Sys so you can close the game

pygame.init() # Start the pygame
screen = pygame.display.set_mode((800,400)) # First number is width and Second is height - Para montar a tela do jogo
pygame.display.set_caption('Jumper')    # Set the title of the game
gameIcon = pygame.image.load('graphics/icon.png')  # Set the icon in a var
pygame.display.set_icon(gameIcon)   # Set the icon in the game

clock = pygame.time.Clock()     # Add a timer
test_font = pygame.font.Font('font/Pixeltype.ttf', 30)   # Add a font


sky_surface = pygame.image.load('../TestPassagem/imagem/Sky.png').convert()     # Add a Image
ground_surface = pygame.image.load('graphics/ground.png').convert() # Convert() is used so pygame can run the game better
text_surface = test_font.render('First Game', False, 'Black') # Write the text, say if you want him Anti-Aliase, set the color
snail_surface = pygame.image.load('graphics/snail/snail1.png').convert_alpha()
snail_x_position = 600      #Snail position in a var

# player = pygame.image.load('graphics/Player/player_stand.png')
# enemies = pygame.image.load('graphics/Fly/Fly1.png')
# test_surface = pygame.Surface((100,200)) # First number is width and Second is height
# test_surface.fill('Red')

while True:     # Loop para rodar o jogo
    for event in pygame.event.get():
        if event.type == pygame.QUIT:   # Event to close the game
            pygame.quit()
            exit()


    screen.blit(sky_surface,(0,0))      # Add things to the surface
    screen.blit(ground_surface,(0,300))
    screen.blit(text_surface,(350,30))
    snail_x_position += -3      # Change the x position of the Snail after each loop
    if snail_x_position < -100:
        snail_x_position = 800

    screen.blit(snail_surface,(snail_x_position, 260))

    # screen.blit(player, (20, 220))
    # screen.blit(enemies, (700, 100))

    pygame.display.update()
    clock.tick(60)      # Say how many times the image is updated in a second, try putting it to 1 or 600 to test





